export const data = [
  {
    id: 1,
    title: "Task 1",
    status: "On review",
    user: "elmar@mail.com",
    created: "10.10.2022",
    description: "Bla bla bla",
    resposible: "mamed@gmail.com",
    avatar: "https://www.vokrug.tv/pic/person/9/b/5/e/9b5e14c5dfdfa5da3707bf7913f859fb.jpg"
  },
  {
  id: 2,
  title: "Task 2",
  status: "Done",
  user: "elmar@mail.com",
  created: "10.10.2022",
  description: "Bla bla bla",
  resposible: "mamed@gmail.com",
  avatar: "https://uznayvse.ru/images/catalog/2022/2/sam-worthington_4.jpg"
  },
  {
  id: 3,
  title: "Task 3",
  status: "Done",
  user: "elmar@mail.com",
  created: "10.10.2022",
  description: "Bla bla bla",
  resposible: "mamed@gmail.com",
  avatar: "https://www.vokrug.tv/pic/person/9/b/5/e/9b5e14c5dfdfa5da3707bf7913f859fb.jpg"
  },
  {
    id: 4,
    title: "Task 4",
    status: "In process",
    user: "elmar@mail.com",
    created: "10.10.2022",
    description: "Bla bla bla",
    resposible: "mamed@gmail.com",
    avatar: "https://avatars.mds.yandex.net/get-kinopoisk-image/1777765/0a0fafc5-c3dc-4583-ba83-ac30ee075724/280x420"
  },
  {
    id: 5,
    title: "Task 5",
    status: "Done",
    user: "elmar@mail.com",
    created: "10.10.2022",
    description: "Bla bla bla",
    resposible: "mamed@gmail.com",
    avatar: "https://avatars.mds.yandex.net/get-kinopoisk-image/1777765/0a0fafc5-c3dc-4583-ba83-ac30ee075724/280x420"
  },
  {
    id: 6,
    title: "Task 6",
    status: "On review",
    user: "elmar@mail.com",
    created: "10.10.2022",
    description: "Bla bla bla",
    resposible: "mamed@gmail.com",
    avatar: "https://uznayvse.ru/images/catalog/2022/2/sam-worthington_4.jpg"
  },
  {
  id: 7,
  title: "Task 7",
  status: "Done",
  user: "elmar@mail.com",
  created: "10.10.2022",
  description: "Bla bla bla",
  resposible: "mamed@gmail.com",
  avatar: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDz74te_zgt40_LDz3TphSDlkvzVIEem-uRn7VZCh_&s"
  },
  {
  id: 8,
  title: "Task 8",
  status: "Done",
  user: "elmar@mail.com",
  created: "10.10.2022",
  description: "Bla bla bla",
  resposible: "mamed@gmail.com",
  avatar: "https://uznayvse.ru/images/catalog/2022/2/sam-worthington_4.jpg"
  },
  {
    id: 9,
    title: "Task 9",
    status: "In process",
    user: "elmar@mail.com",
    created: "10.10.2022",
    description: "Bla bla bla",
    resposible: "mamed@gmail.com",
    avatar: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDz74te_zgt40_LDz3TphSDlkvzVIEem-uRn7VZCh_&s"
  },
  {
    id: 10,
    title: "Task 10",
    status: "",
    user: "elmar@mail.com",
    created: "10.10.2022",
    description: "Bla bla bla",
    resposible: "mamed@gmail.com",
    avatar: "https://uznayvse.ru/images/catalog/2022/2/sam-worthington_4.jpg"
  },
  {
    id: 11,
    title: "Task 10",
    status: "In process",
    user: "elmar@mail.com",
    created: "10.10.2022",
    description: "Bla bla bla",
    resposible: "mamed@gmail.com",
    avatar: "https://uznayvse.ru/images/catalog/2022/2/sam-worthington_4.jpg"
  }
];